package com.dhbrasil.mvc.aula22.service;

import com.dhbrasil.mvc.aula22.model.Veiculo;

import java.util.List;

public interface VeiculoService {
    List<Veiculo> listVeiculo();
}
