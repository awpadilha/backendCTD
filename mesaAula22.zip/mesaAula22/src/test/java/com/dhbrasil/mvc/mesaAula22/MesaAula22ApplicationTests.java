package com.dhbrasil.mvc.mesaAula22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MesaAula22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
