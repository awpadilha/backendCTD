package com.dhbrasil.mvc.mesaAula22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MesaAula22Application {

	public static void main(String[] args) {
		SpringApplication.run(MesaAula22Application.class, args);
	}

}
